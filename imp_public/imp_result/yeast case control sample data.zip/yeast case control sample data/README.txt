Please submit this yeast case control example data along with the following parameters.

=======================
Organism: yeast
=======================
Seed genes: seed list.txt
======================
Target genes: "Derive Target genes automatically"
#Target genes: any integer number larger than zero
=====================================
Expression data: exp data.txt
Data type: Case-control
#Case samples: 6
#Control samples: 6
=======================

Click the Submit button to begin the analysis!