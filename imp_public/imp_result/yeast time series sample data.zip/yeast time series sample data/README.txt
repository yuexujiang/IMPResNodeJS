Please submit this yeast time series example data along with the following parameters.

=======================
Organism: yeast
=======================
Seed genes: Seed_genes.txt
======================
Target genes: "Derive Target genes automatically"
#Target genes: any integer number larger than zero
=====================================
Expression data: Expression_data.txt
Data type: Time-series
#Time points: 7
#Replicates: 3
=======================

Click the Submit button to begin the analysis!